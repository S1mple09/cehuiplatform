<template>
  <div class="dashboard">
    <!-- 顶部导航栏 -->
    <header class="header">
      <div class="search-bar">
        <input 
          type="text" 
          placeholder="搜索..." 
          v-model="searchQuery"
          @keyup.enter="handleSearch"
        />
        <button @click="handleSearch">搜索</button>
      </div>
      
      <div class="user-profile">
        <img 
          :src="user.avatar || '/default-avatar.png'" 
          alt="用户头像"
          class="avatar"
          @click="showProfileModal = true"
        />
        <span class="username">{{ user.username }}</span>
      </div>
    </header>

    <!-- 主要内容区域 -->
    <main class="content">
      <!-- 这里放仪表盘主要内容 -->
    </main>

    <!-- 用户信息模态框 -->
    <ProfileModal 
      v-if="showProfileModal"
      :user="user"
      @close="showProfileModal = false"
      @update="handleProfileUpdate"
    />
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { useAuthStore } from '../stores/auth'
import ProfileModal from '../components/ProfileModal.vue'

export default {
  components: { ProfileModal },
  setup() {
    const authStore = useAuthStore()
    const user = ref({})
    const searchQuery = ref('')
    const showProfileModal = ref(false)

    onMounted(() => {
      user.value = authStore.user
    })

    const handleSearch = () => {
      // 实现搜索逻辑
      console.log('搜索:', searchQuery.value)
    }

    const handleProfileUpdate = (updatedUser) => {
      user.value = updatedUser
    }

    return {
      user,
      searchQuery,
      showProfileModal,
      handleSearch,
      handleProfileUpdate
    }
  }
}
</script>

<style scoped>
.dashboard {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  background: #fff;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.search-bar {
  display: flex;
  gap: 0.5rem;
}

.user-profile {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
}

.content {
  flex: 1;
  padding: 1rem;
}
</style>